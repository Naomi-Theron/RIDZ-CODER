const fs = require('fs');

global.owner = ["237678687593"];  
global.sudo = ["237678687593"]; 
global.prefixz = ".";
global.versions = "1.0.0";
global.MENU_IMAGE_URL = "https://files.catbox.moe/do545q.jpg";

global.mess = {
    owner: "This command is only preserved for owner and sudo",
    notadmin: "Please this command is only for group admins!",
    botnotadmin: "Please first make bot admin",
    notgroup: "This command can only be used in groups!"
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    delete require.cache[file];
    require(file);
});