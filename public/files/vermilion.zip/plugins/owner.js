/* Kelvin Tech*/

const fs = require('fs');
const path = require('path');

module.exports = [
    {
        command: ['getpp', 'profilepic', 'pp'],
        category: 'owner',
        description: 'Get profile picture of a user',
        
        async operate(context) {
            const { ridzcoder, m, reply, react } = context;
            
            if (!m.quoted) {
                await react('📷');
                return reply('Reply to a user to get their profile picture.');
            }

            await react('📷');

            const userId = m.quoted.sender;

            try {
                const ppUrl = await ridzcoder.profilePictureUrl(userId, 'image');

                await ridzcoder.sendMessage(m.chat, 
                    { 
                        image: { url: ppUrl }, 
                        caption: `⌘ *Profile Picture of:* @${userId.split('@')[0]}`,
                        mentions: [userId]
                    }, 
                    { quoted: m }
                );
                
                await react('✅');
            } catch {
                await ridzcoder.sendMessage(m.chat, { 
                    image: { url: 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png' }, 
                    caption: '⚠️ No profile picture found.' 
                }, { quoted: m });
            }
        }
    },
    {
        command: ['join'],
        category: 'owner',
        description: 'Join a group using invite link',
        
        async operate(context) {
            const { ridzcoder, m, reply, text, Access } = context;
            
            if (!Access) return reply(global.mess.owner);
            
            if (!text) {
                return reply('Please provide a group invite link\nExample: .join https://chat.whatsapp.com/xxxxxx');
            }
            
            try {
                const inviteCode = text.split('chat.whatsapp.com/')[1];
                if (!inviteCode) return reply('Invalid invite link');
                
                const group = await ridzcoder.groupAcceptInvite(inviteCode);
                reply(`✅ Successfully joined group!\nGroup ID: ${group}`);
            } catch (error) {
                reply(`Failed to join group: ${error.message}`);
            }
        }
    },
    {
        command: ['leave'],
        category: 'owner',
        description: 'Leave current group',
        
        async operate(context) {
            const { ridzcoder, m, reply, isGroup, Access } = context;
            
            if (!Access) return reply(global.mess.owner);
            if (!isGroup) return reply('This command can only be used in groups');
            
            await reply('👋 Goodbye! Leaving group...');
            await ridzcoder.groupLeave(m.chat);
        }
    },
    {
        command: ['block'],
        category: 'owner',
        description: 'Block a user',
        
        async operate(context) {
            const { ridzcoder, m, reply, quoted, Access } = context;
            
            if (!Access) return reply(global.mess.owner);
            
            let user = m.mentionedJid[0] || (quoted ? quoted.sender : null);
            
            if (!user) {
                return reply('Please mention or reply to a user to block');
            }
            
            try {
                await ridzcoder.updateBlockStatus(user, 'block');
                reply(`✅ Blocked @${user.split('@')[0]}`, { mentions: [user] });
            } catch (error) {
                reply(`Failed to block user: ${error.message}`);
            }
        }
    },
    {
        command: ['unblock'],
        category: 'owner',
        description: 'Unblock a user',
        
        async operate(context) {
            const { ridzcoder, m, reply, quoted, Access } = context;
            
            if (!Access) return reply(global.mess.owner);
            
            let user = m.mentionedJid[0] || (quoted ? quoted.sender : null);
            
            if (!user) {
                return reply('Please mention or reply to a user to unblock');
            }
            
            try {
                await ridzcoder.updateBlockStatus(user, 'unblock');
                reply(`✅ Unblocked @${user.split('@')[0]}`, { mentions: [user] });
            } catch (error) {
                reply(`Failed to unblock user: ${error.message}`);
            }
        }
    }
];