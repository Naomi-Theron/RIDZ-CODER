module.exports = [
    {
        command: ['close', 'mute'],
        category: 'group',
        description: 'Close the group (only admins can send messages)',
        
        async operate(context) {
            const { ridzcoder, isBotAdmin, isGroupAdmin, m, reply, isGroup } = context;
            
            if (!isGroup) return reply(global.mess.notgroup);
            if (!isGroupAdmin) return reply(global.mess.notadmin);
            if (!isBotAdmin) return reply(global.mess.botnotadmin);
            
            try {
                await ridzcoder.groupSettingUpdate(m.chat, "announcement");
                reply("*Group closed successfully!*\n\nOnly admins can send messages now.");
                await ridzcoder.sendMessage(m.chat, { react: { text: "🔒", key: m.key } });
            } catch (error) {
                console.error('Error closing group:', error);
                reply("Failed to close group. Make sure bot has admin permissions.");
            }
        }
    },
    {
        command: ['open', 'unmute'],
        category: 'group',
        description: 'Open the group (all members can send messages)',
        
        async operate(context) {
            const { ridzcoder, isBotAdmin, isGroupAdmin, m, reply, isGroup } = context;
            
            if (!isGroup) return reply(global.mess.notgroup);
            if (!isGroupAdmin) return reply(global.mess.notadmin);  
            if (!isBotAdmin) return reply(global.mess.botnotadmin);
            
            try {
                await ridzcoder.groupSettingUpdate(m.chat, "not_announcement");
                reply("🔓 *Group opened successfully!*\n\nAll members can send messages now.");
                await ridzcoder.sendMessage(m.chat, { react: { text: "🔓", key: m.key } });
            } catch (error) {
                console.error('Error opening group:', error);
                reply("Failed to open group. Make sure bot has admin permissions.");
            }
        }
    },
{
    command: ['promote'],
    category: 'group',
    description: 'Promote a user to admin',
    
    async operate(context) {
        const { ridzcoder, isBotAdmin, isGroupAdmin, m, reply, isGroup, args, sender } = context;
        
        if (!isGroup) return reply(global.mess.notgroup);
        if (!isGroupAdmin) return reply(global.mess.notadmin);
        if (!isBotAdmin) return reply(global.mess.botnotadmin);
        
        // Get mentioned user or replied user
        let target = m.quoted?.sender || args[0]?.replace('@', '') + '@s.whatsapp.net';
        if (!target) return reply("Tag or reply to the user you want to promote!");
        
        try {
            await ridzcoder.groupParticipantsUpdate(m.chat, [target], 'promote');
            reply(`✅ Successfully promoted @${target.split('@')[0]} to admin!`);
        } catch (error) {
            reply("Failed to promote user. Make sure bot has admin rights.");
        }
    }
},
{
    command: ['demote'],
    category: 'group',
    description: 'Demote a user from admin',
    
    async operate(context) {
        const { ridzcoder, isBotAdmin, isGroupAdmin, m, reply, isGroup, args } = context;
        
        if (!isGroup) return reply(global.mess.notgroup);
        if (!isGroupAdmin) return reply(global.mess.notadmin);
        if (!isBotAdmin) return reply(global.mess.botnotadmin);
        
        let target = m.quoted?.sender || args[0]?.replace('@', '') + '@s.whatsapp.net';
        if (!target) return reply("Tag or reply to the user you want to demote!");
        
        try {
            await ridzcoder.groupParticipantsUpdate(m.chat, [target], 'demote');
            reply(`✅ Demoted @${target.split('@')[0]} from admin.`);
        } catch (error) {
            reply("Failed to demote user.");
        }
    }
},
{
    command: ['kick', 'remove'],
    category: 'group',
    description: 'Remove a user from the group',
    
    async operate(context) {
        const { ridzcoder, isBotAdmin, isGroupAdmin, m, reply, isGroup, args } = context;
        
        if (!isGroup) return reply(global.mess.notgroup);
        if (!isGroupAdmin) return reply(global.mess.notadmin);
        if (!isBotAdmin) return reply(global.mess.botnotadmin);
        
        let target = m.quoted?.sender || args[0]?.replace('@', '') + '@s.whatsapp.net';
        if (!target) return reply("Tag or reply to the user you want to kick!");
        
        try {
            await ridzcoder.groupParticipantsUpdate(m.chat, [target], 'remove');
            reply(`👋 User @${target.split('@')[0]} was removed from the group.`);
        } catch (error) {
            reply("Failed to kick user.");
        }
    }
},
{
    command: ['add'],
    category: 'group',
    description: 'Add a user to the group',
    
    async operate(context) {
        const { ridzcoder, isBotAdmin, isGroupAdmin, m, reply, isGroup, args } = context;
        
        if (!isGroup) return reply(global.mess.notgroup);
        if (!isGroupAdmin) return reply(global.mess.notadmin);
        if (!isBotAdmin) return reply(global.mess.botnotadmin);
        
        const number = args[0]?.replace(/[^0-9]/g, '');
        if (!number) return reply("Provide the number to add! Example: .add 1234567890");
        
        const target = `${number}@s.whatsapp.net`;
        
        try {
            await ridzcoder.groupParticipantsUpdate(m.chat, [target], 'add');
            reply(`✅ Added @${number} to the group!`);
        } catch (error) {
            reply("Failed to add user. Make sure the number is valid and hasn't left the group before.");
        }
    }
}
];