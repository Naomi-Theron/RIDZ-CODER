const axios = require('axios');
const yts = require('yt-search');

module.exports = [
    {
        command: ['play', 'song', 'ytplay'],
        category: 'download',
        description: 'Download audio from YouTube (alternative)',
        
        async operate(context) {
            const { kelvin, m, reply, react, text } = context;
            
            if (!text) return reply("*Please provide a song name!*\nExample: `.play wrong places by Joshua baraka`");
            
            try {
                await react("🎵");
                
                const searchQuery = text.trim();
                const { videos } = await yts(searchQuery);
                
                if (!videos || videos.length === 0) {
                    return reply("⚠️ *No results found!*");
                }
                
                const video = videos[0];
                
                await reply(`🎵 *Found:* ${video.title}\n⏳ Downloading...`);
                
                const apiUrl = `https://yt-dl.officialhectormanuel.workers.dev/?url=${encodeURIComponent(video.url)}`;
                const response = await axios.get(apiUrl);
                const data = response.data;
                
                if (!data?.audio) {
                    return reply("*Failed to get audio URL*");
                }
                
                await kelvin.sendMessage(m.chat, {
                    audio: { url: data.audio },
                    mimetype: "audio/mpeg",
                    fileName: `${video.title.replace(/[^\w\s]/gi, '')}.mp3`
                }, { quoted: m });
                
                await react("✅");
                
            } catch (error) {
                console.error('Error in play command:', error);
                reply("*Download failed*");
                await react("❌").catch(() => {});
            }
        }
    },
    {
        command: ['ytvideo', 'video', 'mp4'],
        category: 'download',
        description: 'Download video from YouTube',
        
        async operate(context) {
            const { kelvin, m, reply, react, text } = context;
            
            if (!text) return reply("*Please provide a song name or URL!*\nExample: `.video despacito`");
            
            try {
                await react("🎥");
                
                let videoUrl = text;
                
                if (!text.includes('youtu')) {
                    const { videos } = await yts(text);
                    if (!videos || videos.length === 0) {
                        return reply("⚠️ *No results found!*");
                    }
                    videoUrl = videos[0].url;
                }
                
                await reply("⏳ *Downloading video... Please wait*");
                
                const apiUrl = `https://yt-dl.officialhectormanuel.workers.dev/?url=${encodeURIComponent(videoUrl)}`;
                const response = await axios.get(apiUrl);
                const data = response.data;
                
                if (!data?.videos || data.videos.length === 0) {
                    return reply("*Failed to get video URL*");
                }
                
                const videoData = data.videos[0];
                
                await kelvin.sendMessage(m.chat, {
                    video: { url: videoData.url },
                    caption: `*${data.title || 'Video'}*`,
                    mimetype: "video/mp4"
                }, { quoted: m });
                
                await react("✅");
                
            } catch (error) {
                console.error('Error in video command:', error);
                reply("*Download failed*");
                await react("❌").catch(() => {});
            }
        }
    }
];