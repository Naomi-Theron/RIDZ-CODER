process.on("uncaughtException", (err) => {
    console.error("Caught exception:", err);
});

console.clear();
console.log('Starting VERMILION MD WhatsApp Bot with much love from Ridz Coder X Theron');

require('./config');

const { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    Browsers,
    jidDecode, 
    fetchLatestBaileysVersion,
    generateWAMessageFromContent,
    downloadContentFromMessage
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const chalk = require('chalk');
const readline = require("readline");
const fs = require('fs');
const NodeCache = require('node-cache');
const FileType = require('file-type');
const path = require('path');
const moment = require('moment-timezone');
const { Boom } = require('@hapi/boom');
const { color } = require('./lib/color');

const {
    smsg,
    runtime,
    sleep,
    fetchJson,
    getBuffer,
    formatSize
} = require('./lib/myfunction');
const pluginManager = require('./lib/PluginManager'); 

const usePairingCode = true;
const timezones = global.timezones || "Africa/Kampala";
const msgRetryCounterCache = new NodeCache();

const { makeInMemoryStore } = require("./lib/store/");
const store = makeInMemoryStore({
    logger: pino().child({ level: 'silent', stream: 'store' })
});

const question = (text) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => {
        rl.question(text, (ans) => {
            rl.close();
            resolve(ans);
        });
    });
};

const sessionDir = path.join(__dirname, 'sessions');
const credsPath = path.join(sessionDir, 'creds.json');

async function loadAllPlugins() {
    try {
        const count = pluginManager.loadPlugins();
        console.log(chalk.green(`✅ Loaded ${count} plugins successfully!`));
        const plugins = pluginManager.getAllPlugins();
        return plugins;
    } catch (error) {
        console.error(chalk.red(`Error loading plugins: ${error.message}`));
        return {};
    }
}


async function startBot() {

    const plugins = await loadAllPlugins();
    global.plugins = plugins;

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    let waVersion;
    try {
        const { version } = await fetchLatestBaileysVersion();
        waVersion = version;
        console.log("[ VERMILION MD ] Connecting to WhatsApp ⏳️...");
    } catch (error) {
        console.log(chalk.yellow(`[⚠️] Using stable fallback version`));
        waVersion = [2, 3000, 1017546695]; 
    }

    const ridzcoder = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: !usePairingCode,
        auth: state,
        version: waVersion,
        browser: ["Windows", "Edge", "120.0.0.0"],
        msgRetryCounterCache: msgRetryCounterCache
    });

    if (usePairingCode && !ridzcoder.authState.creds.registered) {
        console.log(chalk.yellow('Authentication required...'));
        const phoneNumber = await question(chalk.greenBright("Enter WhatsApp number (e.g 2567********):\n"));
        const code = await ridzcoder.requestPairingCode(phoneNumber.trim());
        console.log(chalk.cyan(`\nYour Pairing Code: ${code}\n`));
        console.log(chalk.yellow('Enter this code in your WhatsApp Linked Devices section'));
    }

    store.bind(ridzcoder.ev);

    ridzcoder.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server
                ? decode.user + '@' + decode.server
                : jid;
        }
        return jid;
    };

    const botNumber = await ridzcoder.decodeJid(ridzcoder.user?.id) || 'default';

    ridzcoder.ev.on('messages.upsert', async chatUpdate => {
        try {
            let mek = chatUpdate.messages[0];
            if (!mek.message) return;

            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage')
                ? mek.message.ephemeralMessage.message
                : mek.message;

            if (mek.key && mek.key.remoteJid === 'status@broadcast') return;

            let m = smsg(ridzcoder, mek, store);

            const result = await require('./start/system')(ridzcoder, m, chatUpdate, mek, store, plugins);
            
            if (result && result.found === false) {
                if (result.command) {
                    console.log(chalk.yellow(`⚠ Command not found: ${result.command}`));
                }
            }

        } catch (err) {
            console.error(chalk.red('Message handler error:'), err);
        }
    });

    ridzcoder.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = ridzcoder.decodeJid(contact.id);
            if (store && store.contacts) {
                store.contacts[id] = { id, name: contact.notify };
            }
        }
    });

    ridzcoder.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            console.log(color(lastDisconnect.error, 'deeppink'));
            
            if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
                console.log(chalk.yellow.bold('⚠️ Stream error - Attempting to reconnect...'));
                await sleep(5000);
                await startBot();
            } else if (reason === DisconnectReason.badSession) {
                console.log(chalk.red.bold(`Bad session file, please delete session and scan again`));
                console.log(chalk.yellow('Cleaning session and restarting...'));
                await sleep(5000);
                await startBot();
            } else if (reason === DisconnectReason.connectionClosed) {
                console.log(chalk.yellow.bold('Connection closed, reconnecting...'));
                await sleep(3000);
                await startBot();
            } else if (reason === DisconnectReason.connectionLost) {
                console.log(chalk.yellow.bold('Connection lost, trying to reconnect...'));
                await sleep(3000);
                await startBot();
            } else if (reason === DisconnectReason.connectionReplaced) {
                console.log(chalk.red.bold('Connection replaced, another new session opened'));
                console.log(chalk.yellow('Restarting with new session...'));
                await sleep(5000);
                await startBot();
            } else if (reason === DisconnectReason.loggedOut) {
                console.log(chalk.red.bold(`Device logged out, please scan again`));
                console.log(chalk.yellow('Attempting to re-authenticate...'));
                await sleep(5000);
                await startBot();
            } else if (reason === DisconnectReason.restartRequired) {
                console.log(chalk.yellow.bold('Restart required, restarting...'));
                await sleep(2000);
                await startBot();
            } else if (reason === DisconnectReason.timedOut) {
                console.log(chalk.yellow.bold('Connection timed out, reconnecting...'));
                await sleep(3000);
                await startBot();
            } else {
                console.log(chalk.yellow.bold(`⚠️ Unknown disconnect (${reason}), reconnecting...`));
                await sleep(5000);
                await startBot();
            }
        } else if (connection === "connecting") {
            console.log(chalk.blue.bold('Connecting. . .'));
        } else if (connection === "open") {
            console.log(chalk.greenBright('✅ Connected successfully!'));
            console.log('🤗🤗🤗');
            
            try {
                const welcomeMessage = 
`╭──⧼♛  *VERMILION MD* ⧽───❍
│┃➳ *Status:* ✅ ONLINE
│┃➳ *Prefix:* [ ${global.prefixz || '.'} ]
│┃➳ *Version:* ${global.versions}
│┃➳ *Uptime:* Just Started
│┃➳ *Time:* ${moment().tz(timezones).format('HH:mm:ss')}
│┃➳ *Date:* ${moment().tz(timezones).format('DD/MM/YYYY')}
╰─❖ *ʙʀᴏᴜɢʜᴛ ᴛᴏ ʏᴏᴜ ʙʏ ᴋᴇᴠɪɴ ᴛᴇᴄʜ,ʀɪᴅᴢ ᴄᴏᴅᴇʀ & ᴜʀ ᴛʜᴇʀᴏɴ*`;

                await ridzcoder.sendMessage(ridzcoder.user.id, { 
                    text: welcomeMessage 
                });
                
            } catch (error) {
                console.error('Error sending welcome message:', error);
            }
        }
    });
  
    ridzcoder.ev.on('creds.update', saveCreds);

    return ridzcoder;
}

startBot();

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.yellow(`\n ${__filename} updated! Reloading...\n`));
    delete require.cache[file];
    require(file);
});